# Copyright (c) Secure_Horizon (https://github.com/chamidu200)
# See the file 'LICENSE' for copying permission
# ----------------------------------------------------------------------------------------------------------------------------------------------------------|
# EN: 
#     - Do not touch or modify the code below. If there is an error, please contact the owner, but under no circumstances should you touch the code.
#     - Do not resell this tool, do not credit it to yours.
# FR: 
#     - Ne pas toucher ni modifier le code ci-dessous. En cas d'erreur, veuillez contacter le propriétaire, mais en aucun cas vous ne devez toucher au code.
#     - Ne revendez pas ce tool, ne le créditez pas au vôtre.

name_tool       =  "Secure_Horizon"
type_tool       =  "Multi-Tools"
version_tool    =  "6.3"
coding_tool     =  "Python 3"
language_tool   =  "EN"
creator         =  "Secure_Horizon"
platform        =  "Windows 10/11 & Linux"
website         =  "https://securehorizon.kesug.com"
youtube         =  "https://www.youtube.com/@chamidunimsara20052"
github_tool     =  "https://github.com/chamidu200"
telegram        =  "t.me/secure_horizon_MR_C005"
url_config      =  "https://github.com/chamidu200/Remote-Control-Desktop"
url_downloads   =  "https://github.com/chamidu200/Wifi-crack-password"
license         =  "https://github.com/chamidu200/Secure-Horizon-M.R.C005-/blob/main/README.md"
copyright       =  "Copyright (c) Secure_Horizon 'GPL-3.0 license'"