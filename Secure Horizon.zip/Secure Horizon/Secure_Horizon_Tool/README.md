<h1 align="center">Hi 👋, I'm Secure Horizon [ M.R.C005 ]</h1>
<h3 align="center">A passionate frontend developer from Srilanka</h3>
<meta name="google-site-verification" content="C2X2wgLjhHxK_i6M4FZpz32iQvCim6ytFfgjmZF12EY" />
<p align="center"> <img src="https://komarev.com/ghpvc/?username=chamidu200&label=Profile%20views&color=0e75b6&style=flat" alt="chamidu200" /> </p>

<p align="center"> <a href="https://github.com/ryo-ma/github-profile-trophy"><img src="https://github-profile-trophy.vercel.app/?username=chamidu200" alt="chamidu200" /></a> </p>

### Secure Horizon
---

- 🔭 I’m currently working on **Ethical Hacking**

- 🌱 I’m currently learning **PYTHON , JAVA , C++ , HTML**

- 🤝 I’m looking for help with [Secure Horizon [ M.R.C005 ]](https://www.youtube.com/@chamidunimsara20052)

- 👨‍💻 All of my projects are available at [https://www.youtube.com/@chamidunimsara20052](https://www.youtube.com/@chamidunimsara20052)

- 📝 I regularly write articles on [https://t.me/hackingword24](https://t.me/hackingword24)

- 💬 Ask me about **I will reply in due course**

- 📫 How to reach me **SL.ICT.CHANEL.COM@GMAIL.COM**

- 📄 Know about my experiences [Ethical Hacking](Ethical Hacking)

- ⚡ Fun fact **I THINK I AM FUNNY**

<h3 align="center">Connect with me:</h3>
<p align="center">
<a href="https://www.youtube.com/@chamidunimsara20052" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/youtube.svg" alt="chamidunimsara20052" height="40" width="50" /></a>
</p>

<h3 align="left">Languages and Tools:</h3>
<p align="left"> <a href="https://www.w3schools.com/cpp/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/cplusplus/cplusplus-original.svg" alt="cplusplus" width="40" height="40"/> </a> <a href="https://www.w3schools.com/cs/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/csharp/csharp-original.svg" alt="csharp" width="40" height="40"/> </a> <a href="https://cloud.google.com" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/google_cloud/google_cloud-icon.svg" alt="gcp" width="40" height="40"/> </a> 
<a href="https://www.linux.org/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/linux/linux-original.svg" alt="linux" width="50" height="50"/> </a> 
<a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="50" height="50"/> </a><a href="https://www.w3.org/html/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> </a> <a href="https://www.java.com" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg" alt="java" width="40" height="40"/> </a><a href="https://www.mysql.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg" alt="mysql" width="40" height="40"/> </a>  </p>

<p><img align="left" src="https://github-readme-stats.vercel.app/api/top-langs?username=chamidu200&show_icons=true&locale=en&layout=compact" alt="chamidu200" /></p>

<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=chamidu200&show_icons=true&locale=en" alt="chamidu200" /></p>

<h1 align="center">Tools</h1>

<p align="center">
  <img src="Img/Secure_Horizon.png" width="49%"> 
  <img src="Img/Secure_Horizon-2.png" width="49%"> 
  <img src="Img/Secure_Horizon-3.png" width="49%"> 
  <img src="Img/Builder.png" width="49%">
  <br><br>
</p>

<h1 align="center">Features</h1>
<p>
   
```
┌── ⚒️ - RedTiger-Tools
│   ├── Info
│   └── Site
│
├── 💰 - Paid
│   ├── Obfuscator Tool
│   ├── Rat Discord
│   └── Anonymization Software
│
├── 🕵️‍♂️ - Network Scanner
│   ├── Sql Vulnerability Scanner
│   ├── Website Scanner
│   ├── Website Url Scanner
│   ├── Ip Scanner
│   ├── Ip Port Scanner
│   └── Ip Pinger
│
├── 🔎 - Osint
│   ├── Dox Create
│   ├── Dox Tracker
│   ├── Username Tracker
│   ├── Email Tracker
│   ├── Email Lookup
│   ├── Phone Number Lookup
│   └── Ip Lookup
│
├── 🔧 - Utilities
│   ├── Phishing Attack
│   ├── Password Decrypted Attack
│   ├── Password Encrypted
│   ├── Search In DataBase
│   ├── Dark Web Links
│   └── Ip Generator
│
├── ☠️ - Virus Builder
│   ├── Stealer
│   │   ├── System Info: User, System, Ip, Disk, Screen, Location, etc.
│   │   ├── Discord Token: Token, Email, Phone, Id, Username, etc.
│   │   ├── Discord Injection: Email/Password Changed, Login, Card/Paypal Added, Nitro Bought, etc.
│   │   ├── Browser Steal: Passwords, History, Cookies, Downloads, Cards, etc.
│   │   ├── Roblox Cookie: Cookie, Id, Username, etc.
│   │   ├── Camera Capture: Record the victim's computer camera.
│   │   └── Screenshot: Capture the victim's computer screen.
│   │
│   └── Malware
│       ├── Block Key
│       ├── Block Mouse
│       ├── Block Task Manager
│       ├── Block AV Website
│       ├── Shutdown
│       ├── Spam Open Program
│       ├── Spam Create File
│       ├── Fake Error
│       ├── Launch At Startup
│       ├── Anti Vm & Debug
│       └── Restart Every 5min
│
├── 📞 - Discord Tools
│   ├── Token Discord
│   │   ├── Discord Token Info
│   │   ├── Discord Token Nuker
│   │   ├── Discord Token Joiner
│   │   ├── Discord Token Leaver
│   │   ├── Discord Token Login
│   │   ├── Discord Token To Id And Brute
│   │   ├── Discord Token Server Raid
│   │   ├── Discord Token Spammer
│   │   ├── Discord Token Delete Friends
│   │   ├── Discord Token Block Friends
│   │   ├── Discord Token Mass Dm
│   │   ├── Discord Token Delete Dm
│   │   ├── Discord Token Status Changer
│   │   ├── Discord Token Language Changer
│   │   ├── Discord Token House Changer
│   │   ├── Discord Token Theme Changer
│   │   └── Discord Token Generator
│   │
│   ├── Bot Discord
│   │   ├── Discord Bot Server Nuker
│   │   └── Discord Bot Invite To Id
│   │
│   ├── Webhook Discord
│   │   ├── Discord Webhook Info
│   │   ├── Discord Webhook Delete
│   │   ├── Discord Webhook Spammer
│   │   └── Discord Webhook Generator 
│   │
│   ├── Discord Server Info
│   └── Discord Nitro Generator
│
└── 🎮 - Roblox Tools
    ├── Roblox Cookie Login
    ├── Roblox Cookie Info
    ├── Roblox User Info
    └── Roblox Id Info



```
<br><br>
</p>

<h1 align="center">Requirements</h1>

<h3>Windows:</h3>

<p>
- Install <a href="https://www.python.org/downloads/">Python</a> with the <a href="Img/Python_Path.png">PATH</a> options.<br>
- Windows 10 & 11 or +
</p>

<h3>Linux:</h3>

<p>
- Latest version of <a href="https://www.python.org/downloads/">Python</a>.<br>
- Linux recent version.
<br><br>
</p>

<h1 align="center">Installation</h1>

<a href="https://github.com/chamidu200">Dowloads "Secure_Horizon" Here</a>

<p>